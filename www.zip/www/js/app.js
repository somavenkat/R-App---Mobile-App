// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
})

  .config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider) {

  $ionicConfigProvider.tabs.position('bottom'); //top

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider

  
    .state('login', {
      url: '/login',
      // views: {
      // 'tab-login': {
      templateUrl: 'templates/login.html',
      controller: 'loginCtrl'
      // }
      // }
    })
    

  .state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'templates/tabs.html',
    controller: 'mainCtrl'
  })



    .state('tab.login', {
      url: '/login',
      views: {
        'tab-login': {
          templateUrl: 'templates/login.html',
          controller: 'loginCtrl'
        }
      }
    })

  .state('tab.home', {
      url: '/home',
      views: {
        'tab-home': {
          templateUrl: 'templates/tab-home.html',
          controller: 'homeCtrl'
        }
      }
    })

    .state('tab.home-detail', {
      url: '/questions/:questionId',
      views: {
        'tab-home': {
          templateUrl: 'templates/home-detail.html',
          controller: 'HomeDetailCtrl'
        }
      }
    })

  // Each tab has its own nav history stack:

  .state('tab.dash', {
    url: '/dash',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-dash.html',
        controller: 'DashCtrl'
      }
    }
  })

    .state('tab.adds', {
      url: '/adds',
      views: {
        'tab-adds': {
          templateUrl: 'templates/tab-adds.html',
          controller: 'AddsCtrl'
        }
      }
    })

  .state('tab.chats', {
      url: '/chats',
      views: {
        'tab-chats': {
          templateUrl: 'templates/tab-chats.html',
          controller: 'ChatsCtrl'
        }
      }
    })
    .state('tab.chat-detail', {
      url: '/chats/:chatId',
      views: {
        'tab-chats': {
          templateUrl: 'templates/chat-detail.html',
          controller: 'ChatDetailCtrl'
        }
      }
    })

    // .state('tab.account2', {
    //   url: '/account2',
    //   views: {
    //     'tab-account2': {
    //       templateUrl: 'templates/tab-account2.html',
    //       controller: 'AccountCtrl2'
    //     }
    //   }
    // })
  
    .state('tab.account', {
    url: '/account',
    views: {
      'tab-account': {
        templateUrl: 'templates/tab-account.html',
        controller: 'AccountCtrl'
      }
    }
  });

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/login');

})


//angular.module('starter', ['ionic'])

  .controller('moreCtrl', function ($scope, $ionicActionSheet, $state) {
    $scope.logout = function () {
      alert("ok");
      $state.go('tab.login');
    }

    $scope.showActionsheet = function () {

      $ionicActionSheet.show({
        titleText: 'More',
        buttons: [
          { text: '<i class="icon ion-share"></i> Share' },
          { text: '<i class="icon ion-arrow-move"></i> Refer a friend' },
          { text: '<i class="icon ion-arrow-logout"></i> Logout' },
        ],
        // destructiveText: 'Delete',
        cancelText: 'Cancel',
        cancel: function () {
          console.log('CANCELLED');
        },
        buttonClicked: function (index) {
          if(index==0){
            console.log("share option");
            // window.location.href = '#';
          }
          console.log('BUTTON CLICKED', index);
          return true;
        },
        destructiveButtonClicked: function () {
          console.log('DESTRUCT');
          return true;
        }
      });
    };
    
  })
  
  
  .service('Products', function () {
    this.Items = [{
      "id": 0,
      "Name": "Venkat Soma",
      "image": "https://pbs.twimg.com/profile_images/378800000486564797/b702ddca44aa74c57552e383bbbb4a1c_400x400.jpeg",
      "Description": "hello this is my last message"
    }, {
      "id": 1,
      "Name": "Niranjani",
      "image": "https://mediamass.net/jdd/public/documents/celebrities/6659.jpg",
      "Description": "hello this is my last message"
    }, {
      "id": 2,
      "Name": "Manoharini",
      "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRitEzwmtgQaBObD9HNA_nTQZlgRE6YHTcM25ssHCU_Zjp6ue6bjA",
      "Description": "hello this is my last message"
    }, {
      "id": 3,
      "Name": "Allu Arjun",
      "image": "https://static.myfigurecollection.net/pics/figure/big/600426.jpg?rev=1518502629",
      "Description": "hello this is my last message"
    }]

    return this;
  });

angular.module('starter.services', [])

.factory('Chats', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var chats = [{
    id: 0,
    name: 'Ben Sparrow',
    lastText: 'You on your way?',
    face: 'img/ben.png'
  }, {
    id: 1,
    name: 'Max Lynx',
    lastText: 'Hey, it\'s me',
    face: 'img/max.png'
  }, {
    id: 2,
    name: 'Adam Bradleyson',
    lastText: 'I should buy a boat',
    face: 'img/perry.png'
  }, {
    id: 3,
    name: 'Perry Governor',
    lastText: 'Look at my mukluks!',
    face: 'img/perry.png'
  }, {
    id: 4,
    name: 'Mike Harrington',
    lastText: 'This is wicked good ice cream.',
    face: 'img/mike.png'
  }];

  return {
    all: function() {
      return chats;
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(chatId) {
      for (var i = 0; i < chats.length; i++) {
        if (chats[i].id === parseInt(chatId)) {
          return chats[i];
        }
      }
      return null;
    }
  };
})


  .factory('Questions', function () {
    // Might use a resource here that returns a JSON array

    // Some fake testing data
    var questions = [{
      id: 12345,
      name: 'Ben Sparrow',
      sQuestion: 'How surveys improve healthcare? Cards have become widely used in recent years. They are a great way to contain and organize information, while also setting up predictable expectations for the user. With so much content to display at once, and often so little screen realestate, cards have fast become the design pattern of choice for many companies, including the likes of Google, ',
      face: 'https://www.961api.com/template/landing/images/u3.png'
    }, {
        id: 54548,
        name: 'Ben Sparrow',
        sQuestion: 'More than half use surveys to measure employee satisfaction',
        face: 'https://www.961api.com/template/landing/images/u3.png'
      }, {
        id: 25253,
        name: 'Ben Sparrow',
        sQuestion: 'One-third use surveys to monitor patients’ health and safety habits',
        face: 'https://www.961api.com/template/landing/images/u3.png'
      }, {
        id: 45452,
        name: 'Ben Sparrow',
        sQuestion: 'Nearly 40% use surveys to probe the efficacy of patient safety culture',
        face: 'https://www.961api.com/template/landing/images/u3.png'
      }, {
        id: 75758,
        name: 'Ben Sparrow',
        sQuestion: 'HIPAA compliance?',
        face: 'https://www.961api.com/template/landing/images/u3.png'
      }, {
        id: 75656,
        name: 'Ben Sparrow',
        sQuestion: 'Types of healthcare surveys?',
        face: 'https://www.961api.com/template/landing/images/u3.png'
      }, {
        id: 95958,
        name: 'Ben Sparrow',
        sQuestion: 'Understand your patients’ experiences—and their expectations. Try our easy survey builder and pre-written templates.',
        face: 'https://www.961api.com/template/landing/images/u3.png'
      }, {
        id: 85214,
        name: 'Ben Sparrow',
        sQuestion: 'Understand your patients’ experiences—and their expectations. Try our easy survey builder and pre-written templates.',
        face: 'https://www.961api.com/template/landing/images/u3.png'
      }, {
        id: 85987,
        name: 'Ben Sparrow',
        sQuestion: 'Understand your patients’ experiences—and their expectations. Try our easy survey builder and pre-written templates.',
        face: 'https://www.961api.com/template/landing/images/u3.png'
      }];

    return {
      all: function () {
        return questions;
      },
      remove: function (question) {
        questions.splice(questions.indexOf(question), 1);
      },
      get: function (questionId) {
        for (var i = 0; i < questions.length; i++) {
          if (questions[i].id === parseInt(questionId)) {
            return questions[i];
          }
        }
        return null;
      }
    };
  })
  

  
  .factory('Userquestions', function () {
    // Might use a resource here that returns a JSON array

    // Some fake testing data
    var userquestions = [{
      id: 12345,
      name: 'Ben Sparrow',
      sQuestion: 'How surveys improve healthcare? Cards have become widely used in recent years. They are a great way to contain and organize information, while also setting up predictable expectations for the user. With so much content to display at once, and often so little screen realestate, cards have fast become the design pattern of choice for many companies, including the likes of Google, ',
      face: 'https://www.961api.com/template/landing/images/u3.png'
    }, {
      id: 54548,
      name: 'Ben Sparrow',
      sQuestion: 'More than half use surveys to measure employee satisfaction',
      face: 'https://www.961api.com/template/landing/images/u3.png'
    }];

    return {
      all: function () {
        return userquestions;
      },
      remove: function (question) {
        userquestions.splice(userquestions.indexOf(question), 1);
      },
      get: function (questionId) {
        for (var i = 0; i < userquestions.length; i++) {
          if (userquestions[i].id === parseInt(questionId)) {
            return userquestions[i];
          }
        }
        return null;
      }
    };
  });

  



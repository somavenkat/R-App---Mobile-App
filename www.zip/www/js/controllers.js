var num = '';

angular.module('starter.controllers', ['ionic.contrib.frostedGlass'])

  .controller('DashCtrl', function ($scope, $stateParams, Userquestions, $ionicFrostedDelegate, $ionicScrollDelegate) {
    
    $scope.userquestions = Userquestions.all();

    var messageOptions = [];
    var messageIter = '';
    $scope.messages = [];
    $scope.addQues = function () {

      var date = new Date();
      var hours = date.getHours();
      var minutes = date.getMinutes();
      var ampm = hours >= 12 ? 'pm' : 'am';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      minutes = minutes < 10 ? '0' + minutes : minutes;
      var strTime = hours + ':' + minutes + ' ' + ampm;
      var jkl = {
        id: 12345,
        name: 'Ben Sparrow',
        sQuestion: 'How surveys improve healthcare? Cards have become widely used in recent years. They are a great way to contain and organize information, while also setting up predictable expectations for the user. With so much content to display at once, and often so little screen realestate, cards have fast become the design pattern of choice for many companies, including the likes of Google, ',
        face: 'https://www.961api.com/template/landing/images/u3.png'
      }
      messageOptions.push(jkl);
      console.log(messageOptions);
      var nextMessage = messageOptions[messageIter++ % messageOptions.length];
      $scope.messages.push(angular.extend({}, jkl));
      //$ionicFrostedDelegate.update();
      //$ionicScrollDelegate.scrollBottom(true);
      $scope.message = '';
    };


    $scope.remove = function (question) {
      Userquestions.remove(question);
    };

})

.controller('ChatDetailCtrl', function ($scope, $stateParams, Chats, Products, $ionicFrostedDelegate, $ionicScrollDelegate, $rootScope) {
  $scope.chat = Chats.get($stateParams.chatId);
    // $(".tabs").css("display","none");
    $scope.user = Products.Items[num];
    //console.log($scope.user);

    var messageOptions = [];
    var messageIter = '';
    $scope.messages = [];
    $scope.add = function () {

      var date = new Date();
      var hours = date.getHours();
      var minutes = date.getMinutes();
      var ampm = hours >= 12 ? 'pm' : 'am';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      minutes = minutes < 10 ? '0' + minutes : minutes;
      var strTime = hours + ':' + minutes + ' ' + ampm;
      messageOptions.push({ content: '<p>' + $scope.message + ' <br> <span>' + strTime + '</span></p>' });
      console.log(messageOptions);
      var nextMessage = messageOptions[messageIter++ % messageOptions.length];
      $scope.messages.push(angular.extend({}, nextMessage));
      $ionicFrostedDelegate.update();
      $ionicScrollDelegate.scrollBottom(true);
      $scope.message = '';
    };
  
})


  .controller('HomeDetailCtrl', function ($scope, $stateParams, Questions) {
    console.log("Questions "+Questions);
    $scope.question = Questions.get($stateParams.questionId);
   })

.controller('mainCtrl', function ($scope, $stateParams, $state) {
// alert("ok");
    //$state.go('tab.login');
})

.controller('ChatsCtrl', function ($scope, Chats) {
  $scope.chats = Chats.all();
  $scope.remove = function (chat) {
    Chats.remove(chat);
  };
})

  .controller('homeCtrl', function ($scope, Questions) {

  $scope.questions = Questions.all();
    $scope.remove = function (question) {
      Questions.remove(question);
  };
    // $scope.chat = Chats.get($stateParams.chatId);
})

  .controller('loginCtrl', function ($scope, $state, $ionicPopover) {
   // alert("ok"); 
   $scope.loginShow = true;
   $scope.registerShow = false;
    $scope.login = function () {
      $state.go('tab.home');  
    }
    
    // $scope.chat = Chats.get($stateParams.chatId);
  })


  .controller('AddsCtrl', function ($scope, $state) {
    // alert("ok");
  })

  .controller('AppCtrl', function ($scope, $ionicPopover) {

    $ionicPopover.fromTemplateUrl('templates/popover.html', {
      scope: $scope,
    }).then(function (popover) {
      $scope.popover = popover;
    });

    $scope.demo = 'ios';
    $scope.setPlatform = function (p) {
      document.body.classList.remove('platform-ios');
      document.body.classList.remove('platform-android');
      document.body.classList.add('platform-' + p);
      $scope.demo = p;
    }

  })   

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
});
// $timeout(function () {
//   $ionicViewSwitcher.viewEleIsActive(childElement, false);
// }, 100);